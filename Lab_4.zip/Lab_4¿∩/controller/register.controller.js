const db = require("../db");
class RegisterController {
    async createRegister(req, res) {
        const {surname_prof, grade, user_id} = req.body
        const newRegister = await db.query(
            'INSERT INTO register (surname_prof, grade, user_id) values ($1, $2, $3) RETURNING *',
            [surname_prof, grade, user_id]
        )
        res.json(newRegister.rows[0])
    }
    async getRegistersByUser(req, res) {
        const id = req.query.id
        const register = await db.query('SELECT * FROM register where user_id = $1', [id])
        res.json(register.rows)
    }
    async deleteRegister(req, res) {
        const id = req.params.id
        const user = await db.query('DELETE FROM register where id = $1', [id])
        res.json(user.rows[0])

    }
}

module.exports = new RegisterController()