create TABLE student(
    id SERIAL PRIMARY KEY,
    name VARCHAR(255),
    surname VARCHAR(255)
);

create TABLE register(
    id SERIAL PRIMARY KEY,
    surname_prof VARCHAR(255),
    grade VARCHAR(255),
    user_id INTEGER,
    FOREIGN KEY (user_id) REFERENCES student (id)
);
