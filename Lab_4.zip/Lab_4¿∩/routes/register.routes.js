const Router = require('express')
const router = new Router()
const registerController = require('../controller/register.controller')
const userController = require("../controller/user.controller");

router.post('/register', registerController.createRegister)
router.get('/register', registerController.getRegistersByUser)
router.delete('/register/:id', registerController.deleteRegister)

module.exports = router
