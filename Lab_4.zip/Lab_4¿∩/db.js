const Pool = require('pg').Pool
const pool = new Pool({
    user: "postgres",
    password: "3102",
    host: "localhost",
    port: 5432,
    database: "node_postgres_bd"
})

module.exports = pool
